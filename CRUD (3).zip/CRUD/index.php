<!DOCTYPE html>

<html>
<head> 
	<title> student csv insert </title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<style>
	.box
	{
		max-width:600px;
		width:100%;
		margin: 0 auto;;
	}
	</style>
</head>

<body>

	<div class = "container">
	<br />
		<h3 align = "center">Student csv file editing and importing</h3>
		<br />
		
		<!--submit form -->
		<form  id ="upload_csv" method = "post" enctype = "multipart/form-data">
			<div class = "col-md-3">
				<br />
				<label>Select CSV File</label>
			</div>
			<div class = "col-md-4">
				<input type="file" name="csv_file" id = "csv_file" accept = ".csv" style = "margin-top:15px;" />
			</div>
			<div class = "col-md-5">
				<input type ="submit" name ="upload" id = "upload" value ="Upload" style = "margin-top:10px;" class = "btn btn-info" />
			</div>
			<div style = "clear:both"></div>
		</form>
		<br />
		<br />
		<div id="csv_file_data"></div>
			
	</div>
</body>
</html>

<script>
	$(document).ready(function)
	{
		$('#upload_csv').on('submit', function(event)
		{
			event.preventDefault();
			$.ajax(
			{
				url:"insert.php", method:"POST", data:new FormData(this), dataType: 'json', contentType: false, cache:false, processData:false,
				success:function(data)
				{
					var html = '<table class = "table table-striped table-bordered">';
					if(data.column)
					{
						html += '<tr>';
						for(var count = 0; count < data.column.length; count++)
						{
							html += '<th>' +data.column[count]+ '</th>';
						}
						html += '</tr>';
					}
					if(data.row_data)
					{
						for(var count = 0; count <data.row_data.length; count++)
						{
							html += '<tr>';
							html += '<td class = "studentNum" contentedittable>' +data.row_data[count].studentNum+ '</td>';
							html += '<td class = "firstname" contentedittable>' +data.row_data[count].firstname+ '</td>';
							html += '<td class = "surname" contentedittable>' +data.row_data[count].surname+ '</td>';
							html += '<td class ="code" contentedittable>' +data.row_data[count].code+ '</td>';
							html += '<td class = "description" contentedittable>' +data.row_data[count].description+ '</td>';
							html += '<td class = "grade" contentedittable>' +data.row_data[count].grade+ '</td>';
							html +='</tr>';
						}
					}
					html += '</table>';
					html += '<div align = "center"><button type = "button" id= "import_data" class = "btn btn-success">Import</button></div>';	
					
					$('#csv_file_data').html(html);	
					$('#upload_csv')[0].reset();
				}
			})
		});
		
		<!-- importing data-->
		$(document).on('click', '#import_data', function()
		{
			var studentNum = [];
			var firstname = [];
			var surname = [];
			var code = [];
			var description = [];
			var grade = [];
			$('.studentNum').each(function()
			{
				studentNum.push($(this).text());
			});
			$('.firstname').each(function()
			{
				firstname.push($(this).text());
			});
			$('.surname').each(function()
			{
				surname.push($(this).text());
			});
			$('.code').each(function()
			{
				code.push($(this).text());
			});
			$('.description').each(function()
			{
				description.push($(this).text());
			});
			$('.grade').each(function()
			{
				grade.push($(this).text());
			});
			$.ajax(
			{
				url: "import.php",
				method: "post",
				data: {studentNum:studentNum, firstname:firstname, surname:surname, code:code, description:description, grade:grade},
				success:function(data)
				{
					$('#csv_file_data').html('<div class = "alert alert-success"> Data imported successful</div>');
					
				}
			})
			 
		}):
	});
	
</script>