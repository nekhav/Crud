<?php

if(isset($_FILES['uploaded_file'])){
	
	if($_FILES['uploaded_file']['error'] == 0) {
		
		//connect to database
		$database = "crud";
		$link = mysql_connect("localhost", "root", " ") or die ("could not connect");
		$db = mysql_select_db($database, $link) or die("could not select database");

		//upload file
		$file_data = $_FILES['csv_file']['tmp_name'];
		ini_set("auto_detect_line_endings", true); //auto_detect_line_endings added
		$handle = fopen($file, "r");
		$row = 1;
		while (($data = fgetcsv($handle, 0, ",", "'")) !==FALSE)
			if($row ==1)
			{
				//skip the first row
			}
				else
			{	
				//csv format data lkie this
				//$row[0] = studentNum
				//$row[1] = firstname
				//$row[2] = surname 				
				//$row[3] = code
				//$row[4] = description
				//$row[5] = grade
		
				$query = "
				INSERT INTO student_detail('studentNum', 'firstname', 'surname', 'code', 'description', 'grade')
				VALUES ('".$data[0]."', '".$data[1]."', '".$data[2]."', '".$data[3]."', '".$data[4]."', '".$data[5]."', NOW()
				)";
			
				$result = mysql_query($query);
			
				//checking if it was successfull
				if($result){
					echo 'success! Your file was successfully added!';
				}
				else{
					echo'Error! Failed to insert the file';
				}
		}
		$row++;
	}
}
?>
