<?php

if(isset($_POST["studentNum"]))
{
	//connecting to database
	$connect = new PDO("mysqli:host = localhost; dbname =crud", "root", "");
	$studentNum = $_POST["studentNum"];
	$firstname = $_POST["firstname"];
	$surname = $_POST["surname"];
	$code = $_POST["code"];
	$description = $_POST["description"];
	$grade = $_POST["grade"];
	
	for($count = 0; $count < count($studentNum); $count++)
	{
		//inserting into the student_detail table
		$query .="
		INSERT INTO student_detail(studentNum, firstname, surname, code, description, grade)
		VALUES ('".$studentNum[$count]."', '".$firstname[$count]."', '".$surname[$count]."', '".$code[$count]."', '".$description[$count]."', '".$grade[$count]."');
		";
	}
	$statement = $connect -> prepare($query);
	$statement ->execute();
}

?>